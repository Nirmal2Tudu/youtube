# YouTube Clone Starter (Expo + React Native)

A beginner-friendly Android video browsing app starter. Code editing happens in VS Code; EAS Build compiles the Android APK in the cloud. Android Studio is not required as your editor.

## Included
- Dark video browsing feed
- Search field and category chips
- Video player screen using `expo-video`
- Home, Shorts, Subscriptions and You tabs (some are starter placeholders)
- Cloud APK build configuration (`eas.json`)

## Important
This is a starter/demo app, not a complete YouTube service. It does not yet include user login, server-side uploads, comments, real subscriptions, recommendations, moderation, or creator tools. The sample video and image URLs are public demonstration resources and can change. Replace them with media you own or have permission to use before publishing. The app is not affiliated with YouTube or Google.

## Step 1 — Install Node.js
Install the current Node.js LTS release from https://nodejs.org/ . Close and reopen VS Code after installation.

In VS Code, open Terminal > New Terminal and check:

```powershell
node --version
npm --version
```

If Windows says the commands are not recognized, restart VS Code/computer and check Node.js installation/PATH.

## Step 2 — Create a fresh Expo project (recommended)
To ensure dependencies match the currently supported Expo SDK, run these commands in the VS Code terminal:

```powershell
npx create-expo-app@latest youtube-clone
cd youtube-clone
npx expo install expo-video
```

Then replace the generated `App.js` with the `App.js` from this starter folder, and replace `app.json` and `eas.json` with the versions in this folder. Keep the `package.json` created by Expo so its dependency versions match the SDK. If your generated project uses `app/(tabs)/index.tsx` instead of `App.js`, create a blank-template project with `npx create-expo-app@latest youtube-clone --template blank`, then install `expo-video`.

Alternatively, you can extract this starter ZIP and try `npm install`, but the fresh-project method above is recommended because Expo package versions may advance.

## Step 3 — Preview on a phone
Install Expo Go on your Android phone from https://expo.dev/go . From the project folder, run:

```powershell
npx expo start
```

Scan the QR code with Expo Go. Your computer and phone should normally be on the same Wi-Fi network. Expo Go is for previewing; the APK created in the next steps is a standalone installable app.

## Step 4 — Create an Expo account and install EAS CLI
Create/sign in to an account at https://expo.dev/ . Then run:

```powershell
npm install -g eas-cli
eas login
eas whoami
```

## Step 5 — Build an APK in the cloud
From the root of your project folder, run:

```powershell
eas build --platform android --profile preview
```

Follow any prompts. If asked to create a new Android keystore, allow EAS to generate one for this first build. Wait for the build to finish; the terminal will show a build page/link.

## Step 6 — Install the APK
Open the completed build page and download the `.apk`, or open the install link on your Android phone. If Android asks, allow installation from that browser/file manager for this APK, then install it.

## Troubleshooting
- `node` or `npm` not recognized: install Node.js LTS and restart VS Code.
- Expo dependency mismatch: use a fresh `create-expo-app` project and run `npx expo install expo-video`; do not blindly overwrite its `package.json`.
- Cloud build errors: check the build logs linked by EAS and fix the first error shown.
- Video won't play: check internet connection and try another sample; public demo URLs can change.
- Android package ID: change `com.jskpii.youtubeclone` in `app.json` to a unique reverse-domain ID you control before publishing.

## Official docs
- Expo project setup: https://docs.expo.dev/get-started/create-a-project/
- EAS Build: https://docs.expo.dev/build/setup/
- APK builds: https://docs.expo.dev/build-reference/apk/
