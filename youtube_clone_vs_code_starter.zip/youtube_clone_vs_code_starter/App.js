import React, { useMemo, useState } from "react";
import {
  SafeAreaView, View, Text, TextInput, ScrollView, Image, Pressable,
  StyleSheet, StatusBar, FlatList, useWindowDimensions
} from "react-native";
import { VideoView, useVideoPlayer } from "expo-video";

const VIDEOS = [
  {
    id: "bunny",
    title: "Big Buck Bunny — Open Movie Sample",
    channel: "Blender Open Movies",
    views: "1.2M views",
    age: "2 weeks ago",
    duration: "9:56",
    category: "Animation",
    image: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=900",
    url: "https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
  },
  {
    id: "elephants",
    title: "Elephants Dream — Animated Short Film",
    channel: "Open Film Studio",
    views: "845K views",
    age: "1 month ago",
    duration: "10:53",
    category: "Animation",
    image: "https://images.unsplash.com/photo-1535223289827-42f1e9919769?w=900",
    url: "https://storage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
  },
  {
    id: "sintel",
    title: "Sintel — A Fantasy Short Film",
    channel: "Blender Open Movies",
    views: "2.4M views",
    age: "3 months ago",
    duration: "14:48",
    category: "Film",
    image: "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=900",
    url: "https://storage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4",
  },
  {
    id: "tears",
    title: "Tears of Steel — Sci-Fi Movie Sample",
    channel: "Open Film Studio",
    views: "560K views",
    age: "4 days ago",
    duration: "12:14",
    category: "Film",
    image: "https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?w=900",
    url: "https://storage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
  },
  {
    id: "nature",
    title: "Relaxing Nature Scenes for a Quiet Break",
    channel: "Nature Corner",
    views: "92K views",
    age: "1 week ago",
    duration: "Sample",
    category: "Nature",
    image: "https://images.unsplash.com/photo-1470770841072-f978cf4d019e?w=900",
    url: "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
  },
];

const CATEGORIES = ["All", "Music", "Gaming", "Animation", "Film", "Nature", "Live"];

function VideoPlayerScreen({ video, onClose }) {
  const player = useVideoPlayer(video.url, (p) => {
    p.play();
  });
  const { width } = useWindowDimensions();

  return (
    <SafeAreaView style={styles.playerScreen}>
      <StatusBar barStyle="light-content" backgroundColor="#0f0f0f" />
      <View style={styles.playerHeader}>
        <Pressable onPress={onClose} style={styles.backButton}>
          <Text style={styles.backText}>‹  Back</Text>
        </Pressable>
        <Text numberOfLines={1} style={styles.playerHeaderTitle}>Now playing</Text>
      </View>
      <VideoView
        player={player}
        style={{ width, height: width * 9 / 16, backgroundColor: "#000" }}
        nativeControls
        contentFit="contain"
        fullscreenOptions={{ enable: true }}
      />
      <ScrollView contentContainerStyle={styles.playerDetails}>
        <Text style={styles.videoTitle}>{video.title}</Text>
        <Text style={styles.muted}>{video.views} · {video.age}</Text>
        <View style={styles.channelRow}>
          <View style={styles.avatar}><Text style={styles.avatarText}>{video.channel[0]}</Text></View>
          <View style={{ flex: 1 }}>
            <Text style={styles.channelName}>{video.channel}</Text>
            <Text style={styles.muted}>Sample channel</Text>
          </View>
          <Pressable style={styles.subscribeButton}>
            <Text style={styles.subscribeText}>Subscribe</Text>
          </Pressable>
        </View>
        <Text style={styles.description}>
          This is a starter video screen for your own video app. The sample videos are hosted publicly for demonstration. Replace these links with videos you own or have permission to use before publishing.
        </Text>
        <Text style={styles.sectionHeading}>Up next</Text>
        {VIDEOS.filter((item) => item.id !== video.id).slice(0, 3).map((item) => (
          <View key={item.id} style={styles.upNextRow}>
            <Image source={{ uri: item.image }} style={styles.upNextImage} />
            <View style={{ flex: 1 }}>
              <Text style={styles.cardTitle} numberOfLines={2}>{item.title}</Text>
              <Text style={styles.muted}>{item.channel}</Text>
            </View>
          </View>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

function VideoCard({ video, onPress }) {
  return (
    <Pressable style={styles.videoCard} onPress={onPress}>
      <View>
        <Image source={{ uri: video.image }} style={styles.thumbnail} />
        <View style={styles.duration}><Text style={styles.durationText}>{video.duration}</Text></View>
      </View>
      <View style={styles.cardInfo}>
        <View style={styles.avatar}><Text style={styles.avatarText}>{video.channel[0]}</Text></View>
        <View style={{ flex: 1 }}>
          <Text style={styles.cardTitle} numberOfLines={2}>{video.title}</Text>
          <Text style={styles.muted}>{video.channel}</Text>
          <Text style={styles.muted}>{video.views} · {video.age}</Text>
        </View>
        <Text style={styles.more}>⋮</Text>
      </View>
    </Pressable>
  );
}

export default function App() {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("All");
  const [tab, setTab] = useState("Home");
  const [playing, setPlaying] = useState(null);

  const filteredVideos = useMemo(() => VIDEOS.filter((video) => {
    const matchesQuery = `${video.title} ${video.channel} ${video.category}`.toLowerCase().includes(query.toLowerCase());
    const matchesCategory = category === "All" || video.category === category;
    return matchesQuery && matchesCategory;
  }), [query, category]);

  if (playing) {
    return <VideoPlayerScreen key={playing.id} video={playing} onClose={() => setPlaying(null)} />;
  }

  return (
    <SafeAreaView style={styles.screen}>
      <StatusBar barStyle="light-content" backgroundColor="#0f0f0f" />
      <View style={styles.topBar}>
        <View style={styles.brandRow}>
          <View style={styles.logo}><Text style={styles.logoTriangle}>▶</Text></View>
          <Text style={styles.brand}>YouTube<Text style={styles.brandClone}> Clone</Text></Text>
        </View>
        <View style={styles.topActions}>
          <Pressable style={styles.topIcon} onPress={() => setQuery("")}><Text style={styles.iconText}>＋</Text></Pressable>
          <Pressable style={styles.topIcon}><Text style={styles.iconText}>🔔</Text></Pressable>
          <View style={styles.profile}><Text style={styles.profileText}>U</Text></View>
        </View>
      </View>

      <View style={styles.searchBox}>
        <Text style={styles.searchIcon}>⌕</Text>
        <TextInput
          value={query}
          onChangeText={setQuery}
          placeholder="Search videos"
          placeholderTextColor="#aaa"
          style={styles.searchInput}
          returnKeyType="search"
        />
        {query.length > 0 && <Pressable onPress={() => setQuery("")}><Text style={styles.clearText}>✕</Text></Pressable>}
      </View>

      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.categoryScroller} contentContainerStyle={styles.categoryContent}>
        {CATEGORIES.map((item) => (
          <Pressable key={item} onPress={() => setCategory(item)} style={[styles.categoryChip, category === item && styles.categoryChipActive]}>
            <Text style={[styles.categoryText, category === item && styles.categoryTextActive]}>{item}</Text>
          </Pressable>
        ))}
      </ScrollView>

      {tab === "Home" ? (
        <FlatList
          data={filteredVideos}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => <VideoCard video={item} onPress={() => setPlaying(item)} />}
          contentContainerStyle={styles.feed}
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={<Text style={styles.emptyText}>No videos found. Try another search.</Text>}
        />
      ) : (
        <ScrollView contentContainerStyle={styles.placeholder}>
          <Text style={styles.placeholderIcon}>{tab === "Shorts" ? "▣" : tab === "Subscriptions" ? "▤" : "☺"}</Text>
          <Text style={styles.placeholderTitle}>{tab}</Text>
          <Text style={styles.placeholderText}>
            {tab === "Shorts"
              ? "Short-form video support can be added next."
              : tab === "Subscriptions"
              ? "Subscribed channels will appear here once accounts and a backend are added."
              : "Your profile, history, and saved videos can be connected to an account later."}
          </Text>
          <Pressable style={styles.returnButton} onPress={() => setTab("Home")}><Text style={styles.returnButtonText}>Back to Home</Text></Pressable>
        </ScrollView>
      )}

      <View style={styles.bottomNav}>
        {[
          { name: "Home", icon: "⌂" },
          { name: "Shorts", icon: "▣" },
          { name: "＋", icon: "＋" },
          { name: "Subscriptions", icon: "▤" },
          { name: "You", icon: "☺" },
        ].map((item) => (
          <Pressable key={item.name} style={styles.navItem} onPress={() => item.name === "＋" ? setQuery("") : setTab(item.name)}>
            <Text style={[styles.navIcon, tab === item.name && styles.navIconActive]}>{item.icon}</Text>
            <Text style={[styles.navLabel, tab === item.name && styles.navLabelActive]}>{item.name === "＋" ? "Create" : item.name}</Text>
          </Pressable>
        ))}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: "#0f0f0f" },
  topBar: { height: 56, paddingHorizontal: 16, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  brandRow: { flexDirection: "row", alignItems: "center" },
  logo: { width: 27, height: 19, borderRadius: 6, backgroundColor: "#ff0033", alignItems: "center", justifyContent: "center", marginRight: 7 },
  logoTriangle: { color: "white", fontSize: 12, marginLeft: 2 },
  brand: { color: "#fff", fontSize: 19, fontWeight: "800", letterSpacing: -0.7 },
  brandClone: { color: "#aaa", fontSize: 13, fontWeight: "500" },
  topActions: { flexDirection: "row", alignItems: "center", gap: 14 },
  topIcon: { padding: 3 },
  iconText: { color: "#fff", fontSize: 23 },
  profile: { width: 29, height: 29, borderRadius: 15, backgroundColor: "#2467d1", alignItems: "center", justifyContent: "center" },
  profileText: { color: "#fff", fontWeight: "700" },
  searchBox: { marginHorizontal: 14, marginTop: 5, marginBottom: 10, height: 42, borderRadius: 22, borderWidth: 1, borderColor: "#383838", backgroundColor: "#202020", flexDirection: "row", alignItems: "center", paddingHorizontal: 14 },
  searchIcon: { color: "#ddd", fontSize: 25, marginRight: 8 },
  searchInput: { flex: 1, color: "#fff", fontSize: 15, paddingVertical: 0 },
  clearText: { color: "#ddd", fontSize: 17, paddingHorizontal: 5 },
  categoryScroller: { maxHeight: 44, flexGrow: 0 },
  categoryContent: { paddingHorizontal: 12, alignItems: "center", gap: 8, paddingBottom: 8 },
  categoryChip: { backgroundColor: "#272727", borderRadius: 8, paddingHorizontal: 13, paddingVertical: 8 },
  categoryChipActive: { backgroundColor: "#f1f1f1" },
  categoryText: { color: "#f1f1f1", fontWeight: "600", fontSize: 13 },
  categoryTextActive: { color: "#111" },
  feed: { paddingBottom: 12 },
  videoCard: { marginBottom: 17 },
  thumbnail: { width: "100%", height: 218, backgroundColor: "#252525" },
  duration: { position: "absolute", right: 8, bottom: 8, backgroundColor: "rgba(0,0,0,0.85)", borderRadius: 4, paddingHorizontal: 5, paddingVertical: 2 },
  durationText: { color: "#fff", fontSize: 11, fontWeight: "600" },
  cardInfo: { flexDirection: "row", paddingHorizontal: 12, paddingTop: 11, gap: 10, alignItems: "flex-start" },
  avatar: { width: 38, height: 38, borderRadius: 20, backgroundColor: "#343434", alignItems: "center", justifyContent: "center" },
  avatarText: { color: "#fff", fontWeight: "700", fontSize: 16 },
  cardTitle: { color: "#f5f5f5", fontSize: 15, lineHeight: 20, fontWeight: "600", marginBottom: 4 },
  muted: { color: "#aaa", fontSize: 12, lineHeight: 18 },
  more: { color: "#eee", fontSize: 20, paddingHorizontal: 2 },
  bottomNav: { height: 61, borderTopWidth: 1, borderTopColor: "#282828", backgroundColor: "#0f0f0f", flexDirection: "row", justifyContent: "space-around", alignItems: "center", paddingBottom: 3 },
  navItem: { flex: 1, alignItems: "center", justifyContent: "center", gap: 3 },
  navIcon: { color: "#eee", fontSize: 22, height: 25 },
  navIconActive: { color: "#fff" },
  navLabel: { color: "#aaa", fontSize: 10 },
  navLabelActive: { color: "#fff", fontWeight: "700" },
  emptyText: { color: "#ccc", textAlign: "center", marginTop: 50, fontSize: 15 },
  placeholder: { flexGrow: 1, justifyContent: "center", alignItems: "center", paddingHorizontal: 30, paddingBottom: 50 },
  placeholderIcon: { color: "#eee", fontSize: 50, marginBottom: 12 },
  placeholderTitle: { color: "#fff", fontSize: 22, fontWeight: "700", marginBottom: 8 },
  placeholderText: { color: "#aaa", fontSize: 14, lineHeight: 21, textAlign: "center" },
  returnButton: { backgroundColor: "#f1f1f1", borderRadius: 22, paddingVertical: 11, paddingHorizontal: 20, marginTop: 22 },
  returnButtonText: { color: "#111", fontWeight: "700" },
  playerScreen: { flex: 1, backgroundColor: "#0f0f0f" },
  playerHeader: { height: 48, flexDirection: "row", alignItems: "center", paddingHorizontal: 12, gap: 15 },
  backButton: { paddingVertical: 6, paddingRight: 8 },
  backText: { color: "#fff", fontSize: 16 },
  playerHeaderTitle: { color: "#fff", fontSize: 16, fontWeight: "600", flex: 1 },
  playerDetails: { padding: 15, paddingBottom: 30 },
  videoTitle: { color: "#fff", fontSize: 19, fontWeight: "700", lineHeight: 25, marginBottom: 6 },
  channelRow: { flexDirection: "row", alignItems: "center", gap: 10, marginTop: 17, marginBottom: 16 },
  channelName: { color: "#fff", fontSize: 14, fontWeight: "700" },
  subscribeButton: { backgroundColor: "#f1f1f1", borderRadius: 20, paddingHorizontal: 15, paddingVertical: 9 },
  subscribeText: { color: "#111", fontWeight: "700", fontSize: 13 },
  description: { color: "#ddd", backgroundColor: "#242424", padding: 12, borderRadius: 10, fontSize: 13, lineHeight: 19 },
  sectionHeading: { color: "#fff", fontSize: 17, fontWeight: "700", marginTop: 22, marginBottom: 12 },
  upNextRow: { flexDirection: "row", gap: 10, marginBottom: 12, alignItems: "center" },
  upNextImage: { width: 135, height: 76, borderRadius: 7, backgroundColor: "#333" },
});
